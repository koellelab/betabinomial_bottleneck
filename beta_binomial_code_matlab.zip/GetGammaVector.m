function val = GetGammaVector(x)

val = (x-1):(-1):1;
