function log_likelihood_sitevector = GetBetaBinomialLogLikelihoodAtSite(nu_donor, var_reads_recipient, tot_reads_recipient, nu_recipient, Nb_vals, var_calling_threshold)

%if nu_recipient < var_calling_threshold
%    var_is_absent_from_recipient = 1;
%else
%    var_is_absent_from_recipient = 0;
%end

% added 2/24/2021: handle the possibility of a variant present in the
% donor becoming fixed in the recipient. In this case, easiest thing to do
% is to redefine the donor variant and make that variant not transmitted.
% For example, consider a variant C1000G, with C at 70% freq in the donor
% and G at freq 30% in the donor, and with C at 0.6% freq in the recipient
% and G at freq. 99.4% in the recipient. At a variant calling threshold above 0.6%,
% the G allele would be considered fixed in the recipient. To handle the
% case where G is the focal donor variant, we simply redefine the focal
% donor variant as C, such that nu_donor becomes 70% and nu_recipient
% becomes 0.6%.
if nu_recipient < var_calling_threshold
    var_is_absent_from_recipient = 1;
elseif nu_recipient > (1-var_calling_threshold)
    nu_recipient = 1-nu_recipient;
    nu_donor = 1-nu_donor;
    var_reads_recipient = tot_reads_recipient - var_reads_recipient;
    var_is_absent_from_recipient = 1;
else
    var_is_absent_from_recipient = 0;
end
% end add

cntr = 1;
for Nb = Nb_vals
    log_likelihood_sitevector(1,cntr) = GetBetaBinomialLogLikelihoodAtSiteForNb(nu_donor, var_reads_recipient, tot_reads_recipient, var_is_absent_from_recipient, var_calling_threshold, Nb);
    cntr = cntr + 1;
end
